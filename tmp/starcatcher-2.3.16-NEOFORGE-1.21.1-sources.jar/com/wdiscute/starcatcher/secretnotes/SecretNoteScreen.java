package com.wdiscute.starcatcher.secretnotes;

import com.mojang.blaze3d.platform.InputConstants;
import com.wdiscute.libtooltips.Tooltips;
import com.wdiscute.starcatcher.Starcatcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class SecretNoteScreen extends Screen
{
    private final ResourceLocation background;

    private final String translationKey;
    private final Screen screen;

    int uiX;
    int uiY;

    @Override
    protected void init()
    {
        super.init();
        uiX = (width - 512) / 2;
        uiY = (height - 256) / 2;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTick);

        renderImage(guiGraphics, background);

        for (int i = 0; i < 20; i++)
        {
            String key = translationKey + i;
            if (I18n.exists(key))
            {
                guiGraphics.drawString(this.font, Tooltips.resolveTagsToComponentFromTranslationKey(key), uiX + 140, uiY + 55 + 9 * i, 0x635040, false);
            }
            else
            {
                break;
            }
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        InputConstants.Key key = InputConstants.getKey(keyCode, scanCode);
        if (this.minecraft.options.keyInventory.isActiveAndMatches(key))
        {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose()
    {
        super.onClose();
        if (screen != null)
            Minecraft.getInstance().setScreen(screen);
    }

    public SecretNoteScreen(SecretNote.Note note, Screen screen)
    {
        super(Component.empty());
        this.screen = screen;
        this.translationKey = "gui.secret_note." + note.getSerializedName() + ".";
        this.background = Starcatcher.rl("textures/gui/message/" + note.getTexture() + ".png");
    }

    private void renderImage(GuiGraphics guiGraphics, ResourceLocation rl)
    {
        guiGraphics.blit(rl, uiX, uiY, 0, 0, 512, 256, 512, 256);
    }

    @Override
    public boolean isPauseScreen()
    {
        return false;
    }
}
